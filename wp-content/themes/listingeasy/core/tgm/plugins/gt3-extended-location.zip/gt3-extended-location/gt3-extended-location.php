<?php

/*
Plugin Name: Extended Location
Description: Extended Location - extending location feature for the directory websites
Author: GT3 Themes
Version: 1.0.3
Author URI: https://gt3themes.com
*/

if(!class_exists('GT3_Job_Extended_Location')) {
	class GT3_Job_Extended_Location {
		private static $instance = null;

		private function __construct(){
			add_action('plugins_loaded', array( $this, 'plugins_loaded' ));
			add_action('init', array($this, 'load_textdomain'));
		}

		public static function instance(){
			if(!self::$instance instanceof self) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function load_textdomain(){
			load_plugin_textdomain('gt3_jm_extended_location', false, dirname(plugin_basename(__FILE__)).'/languages/');
		}

		public function plugins_loaded(){
			if(class_exists('WP_Job_Manager_Extended_Location')) {
				add_action('admin_notices', array( $this, 'WP_Job_Manager_Extended_Location' ));
			}

			if(class_exists('WP_Job_Manager')) {
				require_once __DIR__.'/plugin.php';
			} else {
				add_action('admin_notices', array( $this, 'WP_Job_Manager' ));
			}
		}

		function WP_Job_Manager_Extended_Location(){
			?>
			<div class="notice notice-error">
				<p>
					<?php echo sprintf(esc_html__('Plugin "%1$s" active. Deactivate this plugin for correctly work.', 'gt3_jm_extended_location'),
						"WP Job Manager - Extended Location"); ?>
				</p>
			</div>
			<?php
		}

		function WP_Job_Manager(){
			?>
			<div class="notice notice-error">
				<p>
					<?php echo sprintf(esc_html__('Plugin "%1$s" must be installed and activated.', 'gt3_jm_extended_location'),
						"WP Job Manager"); ?>
				</p>
			</div>
			<?php
		}

	}

	GT3_Job_Extended_Location::instance();
}


