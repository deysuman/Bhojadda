/*!
 Version: 1.0
 Author: GT3 Themes
 Website: https//gt3themes.com
 File: admin.js
 Plugin: extended-location
 */
"use strict"
jQuery(function ($) {
	var look = [jQuery('#_job_location'), jQuery('#_candidate_location'), jQuery('#_event_location')];

	jQuery.each(look, function (key, $input) {
		if ($input.length) {
			var lat = gt3_ext_loc.listing_lat ? gt3_ext_loc.listing_lat : gt3_ext_loc.start_geo_lat;
			var lng = gt3_ext_loc.listing_long ? gt3_ext_loc.listing_long : gt3_ext_loc.start_geo_long;

			$input.mapify({
				startGeoLat: lat,
				startGeoLng: lng
			});
			$input.geo_tag_text();
		}
	});

	jQuery('#setting-gt3_ext_loc_start_location').geo_tag_text();
	jQuery('#setting-gt3_ext_loc_start_location').mapify({
		startGeoLat: gt3_ext_loc.start_geo_lat,
		startGeoLng: gt3_ext_loc.start_geo_long,
		latInputId: 'gt3_ext_loc_start_geo_lat',
		lngInputId: 'gt3_ext_loc_start_geo_long'
	});
})

