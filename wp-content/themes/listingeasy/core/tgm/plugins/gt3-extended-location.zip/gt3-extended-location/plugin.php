<?php
if(!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

if(!class_exists('GT3_JM_Extended_location')) {
	class GT3_JM_Extended_location {
		private static $instance = null;
		private $min = '';
		private static $version = '1.0.0';
		private $js_url = '';
		private $css_url = '';

		private function __construct(){
			$this->min = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';
			$this->get_version();
			$this->actions();
			$this->js_url  = plugins_url('/assets/js/', __FILE__);
			$this->css_url = plugins_url('/assets/css/', __FILE__);
		}

		private function get_version(){
			if(!function_exists('get_plugin_data')) {
				require_once(ABSPATH.'wp-admin/includes/plugin.php');
			}
			$plugin_info   = get_plugin_data(dirname(__FILE__).'/gt3-extended-location.php');
			self::$version = $plugin_info['Version'];
		}

		public static function instance(){
			if(!self::$instance instanceof self) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		private function actions(){
			add_action('wp_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ));
			add_action('admin_enqueue_scripts', array( $this, 'admin_enqueue_scripts' ), 5);
			add_filter('job_manager_get_listings', array( $this, 'job_manager_get_listings' ), 20, 2);

			// Save Map geo location
			add_action('job_manager_save_job_listing', array( $this, 'save_listing_geo' ), 30, 2);
			add_action('resume_manager_save_resume', array( $this, 'save_listing_geo' ), 30, 2);
			add_action('wpjm_events_save_event', array( $this, 'save_listing_geo' ), 30, 2);

			add_action('job_manager_job_filters_end', array( $this, 'job_manager_job_filters_end' ));

			// Settings
			add_action('job_manager_settings', array( $this, 'settings' ));
			add_action('admin_init', array( $this, 'register_geo_settings' ));
		}

		public function register_geo_settings(){
			register_setting('job_manager', 'gt3_ext_loc_start_geo_lat');
			register_setting('job_manager', 'gt3_ext_loc_start_geo_long');
		}


		public function settings($settings){
			$settings['gt3_ext_location'] = array(
				esc_html__('GT3 Location Settings', 'gt3_jm_extended_location'),
				array(
					array(
						'name'     => 'gt3_ext_loc_enable_user_ip_location',
						'type'     => 'checkbox',
						'label'    => esc_html__('Auto Location', 'gt3_jm_extended_location'),
						'cb_label' => esc_html__('Enable City Suggest', 'gt3_jm_extended_location'),
						'desc'     => esc_html__('When checked the city of the user will be automatically used to filter results.', 'gt3_jm_extended_location'),						
					),
					array(
						'name'     => 'gt3_ext_loc_enable_map',
						'type'     => 'checkbox',
						'label'    => esc_html__('Submission Form', 'gt3_jm_extended_location'),
						'cb_label' => esc_html__('Display Map', 'gt3_jm_extended_location'),
						'desc'     => esc_html__('When checked there will be a small Google Map positioned beneath the location field.', 'gt3_jm_extended_location'),
						'std'      => 1,
					),
					array(
						'name'       => 'gt3_ext_loc_def_range',
						'type'       => 'number',
						'label'      => esc_html__('Default Range', 'gt3_jm_extended_location'),
						'desc'       => esc_html__('Default Set Range', 'gt3_jm_extended_location'),
						'std'        => 3,
						'attributes' => array(
							'min' => 1,
							'max' => 100,
						),
					),
					array(
						'name'       => 'gt3_ext_loc_min_range',
						'type'       => 'number',
						'label'      => esc_html__('Min Range', 'gt3_jm_extended_location'),
						'desc'       => esc_html__('Min Range', 'gt3_jm_extended_location'),
						'std'        => 1,
						'attributes' => array(
							'min' => 1,
							'max' => 100,
						),
					),
					array(
						'name'       => 'gt3_ext_loc_max_range',
						'type'       => 'number',
						'label'      => esc_html__('Max Range', 'gt3_jm_extended_location'),
						'desc'       => esc_html__('Max Range', 'gt3_jm_extended_location'),
						'std'        => 10,
						'attributes' => array(
							'min' => 1,
							'max' => 100,
						),
					),
					array(
							'name' => 'gt3_ext_loc_radius_unit',
							'type'       => 'select',
							'label'      => esc_html__('Radius Unit', 'gt3_jm_extended_location'),
							'desc'       => esc_html__('Please select the default unit for GPS search', 'gt3_jm_extended_location'),
							'options' => array(
								'mi' => esc_html__('miles','gt3_jm_extended_location'),
								'km' => esc_html__('km','gt3_jm_extended_location'),
							),
							'std'        => 'mi',
					),

					array(
						'name'  => 'gt3_ext_loc_start_location',
						'type'  => 'text',
						'label' => esc_html__('Default Location', 'gt3_jm_extended_location'),
						'desc'  => esc_html__('The default location if the map is enabled', 'gt3_jm_extended_location'),
						'std'   => '',
					)
				),
			);

			return $settings;
		}

		public function wp_enqueue_scripts(){
			wp_enqueue_style('gt3-extended-location', $this->css_url.'extended-location'.$this->min.'.css');
			wp_enqueue_style('rangeslider', $this->css_url.'rangeslider'.$this->min.'.css');
			if(!wp_script_is('google-maps', 'registered')) {
				wp_register_script('google-maps', '//maps.googleapis.com/maps/api/js?v=3.exp&libraries=places');
			}
			wp_enqueue_script('rangeslider', $this->js_url.'rangeslider'.$this->min.'.js', array( 'jquery' ), $this::$version, false);
			wp_enqueue_script('mapify', $this->js_url.'mapify'.$this->min.'.js', array( 'jquery', 'google-maps', 'rangeslider' ), $this::$version, false);
			wp_enqueue_script('geo-tag-text', $this->js_url.'geo-tag-text'.$this->min.'.js', array( 'jquery', 'google-maps' ), $this::$version, false);
			wp_register_script('gt3-extended-location', $this->js_url.'gt3-extended-location'.$this->min.'.js', array( 'jquery', 'google-maps' ), $this::$version, true);

			$job_ext_loc = array(
				'start_point'    => apply_filters('gt3_ext_loc_start_location', get_option('gt3_ext_loc_start_location')),
				'start_geo_lat'  => apply_filters('gt3_ext_loc_start_geo_lat', get_option('gt3_ext_loc_start_geo_lat')),
				'start_geo_long' => apply_filters('gt3_ext_loc_start_geo_long', get_option('gt3_ext_loc_start_geo_long')),
				'enable_map'     => get_option('gt3_ext_loc_enable_map', 1),
				'user_location'  => $this->get_user_location(),
				'l10n'           => array(
					'locked'   => esc_html__('Lock Pin', 'gt3_jm_extended_location'),
					'unlocked' => esc_html__('Unlock Pin', 'gt3_jm_extended_location')
				)
			);

			wp_localize_script('gt3-extended-location', 'gt3_ext_loc', $job_ext_loc);
			wp_enqueue_script('gt3-extended-location');
		}

		public function admin_enqueue_scripts(){
			wp_enqueue_style('gt3-extended-location', $this->css_url.'extended-location'.$this->min.'.css');
			wp_enqueue_style('rangeslider', $this->css_url.'rangeslider'.$this->min.'.css');

			if(wp_script_is('google-maps', 'registered')) {
				wp_deregister_script('google-maps');
			}
			wp_register_script('google-maps', '//maps.googleapis.com/maps/api/js?v=3.exp&libraries=places');
			wp_enqueue_script('rangeslider', $this->js_url.'rangeslider'.$this->min.'.js', array( 'jquery' ), $this::$version, false);
			wp_enqueue_script('mapify', $this->js_url.'mapify'.$this->min.'.js', array( 'jquery', 'google-maps' ), $this::$version, false);

			wp_enqueue_script('geo-tag-text', $this->js_url.'geo-tag-text'.$this->min.'.js', array( 'jquery', 'google-maps' ), $this::$version, false);
			wp_register_script('gt3-extended-location-admin', $this->js_url.'admin'.$this->min.'.js', array( 'jquery', 'google-maps' ), $this::$version, true);

			wp_localize_script('gt3-extended-location-admin', 'gt3_ext_loc', array(
				'start_geo_lat'  => apply_filters('gt3_ext_loc_start_geo_lat', get_option('gt3_ext_loc_start_geo_lat', 40.712784)),
				'start_geo_long' => apply_filters('gt3_ext_loc_start_geo_long', get_option('gt3_ext_loc_start_geo_long', -74.005941)),
				'enable_map'     => get_option('gt3_ext_loc_enable_map', 1),
				'user_location'  => $this->get_user_location(),
				'listing_lat'    => isset($_GET['post']) ? get_post_meta($_GET['post'], 'geolocation_lat', true) : '',
				'listing_long'   => isset($_GET['post']) ? get_post_meta($_GET['post'], 'geolocation_long', true) : '',
				'l10n'           => array(
					'locked'   => esc_html__('Lock Pin', 'gt3_jm_extended_location'),
					'unlocked' => esc_html__('Unlock Pin', 'gt3_jm_extended_location')
				)
			));
			wp_enqueue_script('gt3-extended-location-admin');
		}

		public function get_user_location(){
			if(0 == get_option('gt3_ext_loc_enable_user_ip_location')) {
				return array();
			}

			if(!empty($_SERVER['HTTP_CLIENT_IP'])) {
				$ip = $_SERVER['HTTP_CLIENT_IP'];
			} else if(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])) {
				$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
			} else {
				$ip = $_SERVER['REMOTE_ADDR'];
			}

			$hash = 'gt3_ext_loc_location_'.str_replace('.', '_', $ip);
			if(!$location_data = get_transient($hash)) {
				$response = wp_remote_get('http://ip-api.com/json/'.$ip);

				if(is_wp_error($response)) {
					return array();
				}

				$data = wp_remote_retrieve_body($response);

				if(is_wp_error($data)) {
					return array();
				}

				$location_data = json_decode($data);
				set_transient($hash, $location_data, 60*60*24);
			}

			return $location_data;
		}

		public function job_manager_get_listings($query_args, $args){
			if(isset($_POST) && isset($_POST['form_data'])) {
				parse_str($_POST['form_data'], $_POST['form_data_parse']);

				if(
					(isset($_POST['form_data_parse']['geolocation_lat']) || isset($_POST['form_data_parse']['geolocation_long'])) &&
					(!empty($_POST['form_data_parse']['geolocation_lat']) && !empty($_POST['form_data_parse']['geolocation_long'])) &&
					 ($_POST['form_data_parse']['geolocation_lat'] !== 'undefined' || $_POST['form_data_parse']['geolocation_long'] !== 'undefined')
				) {
					$rad    = isset($_POST['form_data_parse']['gps_range'])
					          && !empty($_POST['form_data_parse']['gps_range'])
					          && is_numeric($_POST['form_data_parse']['gps_range'])
					          && $_POST['form_data_parse']['gps_range'] >= 1
					          && $_POST['form_data_parse']['gps_range'] <= 50
						? round($_POST['form_data_parse']['gps_range'], 3) : 10;
					$type   = (isset($_POST['form_data_parse']['gps_type'])
					           && !empty($_POST['form_data_parse']['gps_type'])
					           && $_POST['form_data_parse']['gps_type'] == 'km')
						? 1 : 1.6;
					$lat1km = 0.009*$type;
					$lng1km = 0.01188*$type;

					$meta = array(
						'relation' => 'AND',
					);
					if(isset($_POST['form_data_parse']['geolocation_lat']) && !empty($_POST['form_data_parse']['geolocation_lat'])) {
						$_POST['form_data_parse']['geolocation_lat'] = (float) $_POST['form_data_parse']['geolocation_lat'];

						$lat_min = $_POST['form_data_parse']['geolocation_lat']-$rad*$lat1km;
						$lng_max = $_POST['form_data_parse']['geolocation_lat']+$rad*$lat1km;

						$meta[] = array(
							'key'     => 'geolocation_lat',
							'value'   => array( $lat_min, $lng_max ),
							'compare' => 'BETWEEN',
							'type'    => 'DECIMAL(10,8)',
						);
					}

					if(isset($_POST['form_data_parse']['geolocation_long']) && !empty($_POST['form_data_parse']['geolocation_long'])) {
						$_POST['form_data_parse']['geolocation_long'] = (float) $_POST['form_data_parse']['geolocation_long'];

						$lng_min = $_POST['form_data_parse']['geolocation_long']-$rad*$lng1km;
						$lng_max = $_POST['form_data_parse']['geolocation_long']+$rad*$lng1km;
						if($lng_min < -180) {
							$lng_min += 360;
						}
						if($lng_max > 180) {
							$lng_max -= 360;
						}
						$meta[] = array(
							'key'     => 'geolocation_long',
							'value'   => $lng_min,
							'compare' => '>',
							'type'    => 'DECIMAL(10,8)',
						);
						$meta[] = array(
							'key'     => 'geolocation_long',
							'value'   => $lng_max,
							'compare' => '<',
							'type'    => 'DECIMAL(10,8)',
						);
					}
					$query_args['meta_query'] = $meta;
				}
			}

			return $query_args;
		}

		public function save_listing_geo($listing_id, $values){
			if(isset($_POST['geolocation_lat'])) {
				update_post_meta($listing_id, 'geolocation_lat', sanitize_text_field($_POST['geolocation_lat']));
			}
			if(isset($_POST['geolocation_long'])) {
				update_post_meta($listing_id, 'geolocation_long', sanitize_text_field($_POST['geolocation_long']));
			}
		}

		public function job_manager_job_filters_end(){
			$min = round(get_option('gt3_ext_loc_min_range', 10), 3);
			$max = round(get_option('gt3_ext_loc_max_range', 50), 3);
			$val = round(get_option('gt3_ext_loc_def_range', 25), 3);
			$gps_type = get_option('gt3_ext_loc_radius_unit', 'mi');
			?>
			<div class="gps_range" id="gps_range">
				<div class="gps_range_wrapper">
					<div class="gps_range_vars"><?php echo esc_html__('Radius:', 'gt3_jm_extended_location'); ?> <span class="current_range"></span></div>
					<div class="gps_type_wrap">
						<label>
							<input type="radio" name="gps_type" value="km" <?php echo $gps_type == 'km' ? 'checked="checked"' : '' ?> /> KM
						</label>
						<label>
							<input type="radio" name="gps_type" value="mi" <?php echo $gps_type == 'mi' ? 'checked="checked"' : '' ?> /> MI
						</label>
					</div>
					<div class="gps_range_slider">
						<input type="range"
							   min="<?=$min?>"
							   max="<?=$max?>"
							   step="0.1"
							   name="gps_range"
							   value="<?=$val?>"
						/>
					</div>
				</div>
			</div>
			<?php
		}
	}

	GT3_JM_Extended_location::instance();
}
