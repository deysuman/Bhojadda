/*!
 Version: 1.0
 Author: GT3 Themes
 Website: https//gt3themes.com
 File: gt3-products-integration.js
 Plugin: gt3-products-integration
 */

"use strict"
jQuery(function ($) {
	if (typeof $.fn.chosen === 'undefined' || typeof gt3_jm_products === 'undefined') {
		return;
	}

	$('.fieldset-products #products, #_gt3_products').chosen(gt3_jm_products);

	$('body').on('click', '.move_jm_products', function (e) {
		e.preventDefault();
		$(this).attr('disabled','disabled');

		$.ajax({
			type: "POST",
			data: {
				action: 'gt3_move_jm_products',
				gt3_move_jm_products_nonce: $(this).closest('td').find('#gt3_move_jm_products_nonce').val(),
				_wp_http_referer: $(this).closest('td').find('input[name="_wp_http_referer"]').val(),
			},
			url: ajaxurl,
			success: function (data) {
				$(this).removeAttr('disabled')
			},
			error: function (e) {
				$(this).removeAttr('disabled')
			}
		});
	})
})

