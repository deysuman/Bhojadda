<?php

/*
Plugin Name: Products Integration
Description: Products Integration - integrate products into directory websites
Author: GT3 Themes
Version: 1.0
Author URI: https://gt3themes.com
*/

if(!class_exists('GT3_JM_Products_Integration')) {
	class GT3_JM_Products_Integration {
		private static $instance = null;

		private function __construct(){
			add_action('plugins_loaded', array( $this, 'plugins_loaded' ));
			add_action('init', array( $this, 'load_textdomain' ));
		}

		public static function instance(){
			if(!self::$instance instanceof self) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		public function load_textdomain(){
			load_plugin_textdomain('gt3_jm_products_integration', false, dirname(plugin_basename(__FILE__)).'/languages/');
		}

		public function plugins_loaded(){
			if(class_exists('WooCommerce') && class_exists('WP_Job_Manager')) {
				require_once __DIR__.'/plugin.php';
			} else {
				add_action('admin_notices', array( $this, 'WP_Job_Manager' ));
			}

			if(class_exists('WP_Job_Manager_Products')) {
				add_action('admin_notices', array( $this, 'WP_Job_Manager_Products' ));
			}
		}

		function WP_Job_Manager_Products(){
			?>
			<div class="notice notice-error">
				<p>
					<?php echo sprintf(esc_html__('Plugin "%1$s" active. Deactivate this plugin for correctly work.', 'gt3_jm_products_integration'),
						"WP Job Manager - Products"); ?>
				</p>
			</div>
			<?php
		}

		function WP_Job_Manager(){
			?>
			<div class="notice notice-error">
				<p>
					<?php echo sprintf(esc_html__('Plugins "%1$s" and "%2$s" must be installed and activated.', 'gt3_jm_products_integration'),
						'WP Job Manager', 'WooCommerce'); ?>
				</p>
			</div>
			<?php
		}

	}

	GT3_JM_Products_Integration::instance();
}


