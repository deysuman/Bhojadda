<?php
if(!defined('ABSPATH')) {
	exit; // Exit if accessed directly.
}

if(!class_exists('GT3_JM_Products_Integration_Plugin')) {
	class GT3_JM_Products_Integration_Plugin {
		private static $instance = null;
		private $min = '';
		private static $version = '1.0.0';
		private $js_url = '';
		private $css_url = '';

		private function __construct(){
			$this->min = defined('SCRIPT_DEBUG') && SCRIPT_DEBUG ? '' : '.min';
			$this->get_version();
			$this->actions();
			$this->js_url  = plugins_url('/assets/js/', __FILE__);
			$this->css_url = plugins_url('/assets/css/', __FILE__);
		}

		private function get_version(){
			if(!function_exists('get_plugin_data')) {
				require_once(ABSPATH.'wp-admin/includes/plugin.php');
			}
			$plugin_info   = get_plugin_data(dirname(__FILE__).'/gt3-products-integration.php');
			self::$version = $plugin_info['Version'];
		}

		public static function instance(){
			if(!self::$instance instanceof self) {
				self::$instance = new self();
			}

			return self::$instance;
		}

		private function actions(){
			// Add products field to submit form
			add_filter('submit_job_form_fields', array( $this, 'submit_job_form_fields' ));

			// Add products field to event submit form

			if(get_option('gt3_enable_products_on_events')) {
				add_filter('submit_event_form_fields', array( $this, 'submit_event_form_fields' ));
			}

			// Save products from submit form
			add_action('job_manager_update_job_data', array( $this, 'update_job_data_products' ), 10, 2);

			// Add products field to backend
			add_filter('job_manager_job_listing_data_fields', array( $this, 'add_listing_data_fields_product' ));

			// Add products field to events backend
			add_filter('wpjm_events_event_fields', array( $this, 'add_event_data_fields_product' ));

			// Display products on listing page
			//add_action('single_job_listing_end', array( $this, 'listing_display_products' ));

			// Save an empty value when no products are in $_POST
			add_action('job_manager_save_job_listing', array( $this, 'save_job_listing_data' ), 25, 2);

			// Delete product when connected listing is deleted
			if(get_option('gt3_delete_products_with_listings')) {
				add_action('wp_trash_post', array( $this, 'delete_product_with_listing' ));
			}

			// check if a post is being set as expired so we can draft a product
			if(get_option('gt3_draft_products_on_listing_expiration')) {
				add_action('save_post', array( $this, 'draft_products_on_listing_expiration' ), 10, 2);
			}

			add_action('wp_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ));
			add_action('admin_enqueue_scripts', array( $this, 'wp_enqueue_scripts' ));

			add_action('job_manager_settings', array( $this, 'admin_settings' ));

			add_action('wp_job_manager_admin_field_button_move', array( $this, 'wp_job_manager_admin_field_button_move' ), 10, 4);

			add_action('wp_ajax_gt3_move_jm_products', array( $this, 'ajax_handler' ));
		}

		public function admin_settings($settings){
			$settings['gt3_products_settings'] = array(
				esc_html__('GT3 Products Integration', 'gt3_jm_products_integration'),
				array(
					array(
						'name'    => 'gt3_products_limit',
						'type'    => 'select',
						'std'     => 'own',
						'label'   => esc_html__('Products Limitation', 'gt3_jm_products_integration'),
						'desc'    => sprintf('%1$s <small>%2$s</small>',
							esc_html__('Which products can listings owners select?', 'gt3_jm_products_integration'),
							esc_html__('Admins will see all products', 'gt3_jm_products_integration')
						),
						'options' => array(
							'own' => esc_html__('Only their own', 'gt3_jm_products_integration'),
							'all' => esc_html__('All', 'gt3_jm_products_integration'),
						),
					),

					array(
						'name'  => 'gt3_select_products_text',
						'type'  => 'text',
						'label' => esc_html__('Select Products Text', 'gt3_jm_products_integration'),
						'std'   => esc_html__('Select Your Services & Products', 'gt3_jm_products_integration'),
						'desc'  => sprintf('<em>%s</em>', esc_html__('Default: "Select Your Services & Products"', 'gt3_jm_products_integration')),
					),

					array(
						'name'  => 'gt3_listing_products_text',
						'type'  => 'text',
						'label' => esc_html__('Listing Products Text', 'gt3_jm_products_integration'),
						'desc'  => sprintf('<em>%s</em>', esc_html__('Default: "Listing Products"', 'gt3_jm_products_integration')),
						'std'   => esc_html__('Listing Products', 'gt3_jm_products_integration'),
					),

					array(
						'name'       => 'gt3_max_selected_options',
						'type'       => 'number',
						'attributes' => array(
							'min'  => 0,
							'step' => 1,
						),
						'label'      => esc_html__('Max. selected products', 'gt3_jm_products_integration'),
						'desc'       => sprintf('<em>%s</em>', esc_html__('Max selected products ("0" for unlimited).', 'gt3_jm_products_integration')),
						'std'        => 5,
					),

					array(
						'name'        => 'gt3_enable_products_on_listings',
						'std'         => '1',
						'placeholder' => '',
						'label'       => esc_html__('Enable Products List for Job', 'gt3_jm_products_integration'),
						'cb_label'    => esc_html__('Enable product selection when submitting a listing using [submit_job_form]', 'gt3_jm_products_integration'),
						'desc'        => esc_html__('Allow users to attach products to listings when submitting a listing on the frontend.', 'gt3_jm_products_integration'),
						'type'        => 'checkbox'
					),

					array(
						'name'        => 'gt3_enable_products_on_events',
						'std'         => '1',
						'placeholder' => '',
						'label'       => esc_html__('Enable Products List for Events', 'gt3_jm_products_integration'),
						'cb_label'    => esc_html__('Enable product selection when submitting an event using [submit_event_form]', 'gt3_jm_products_integration'),
						'desc'        => esc_html__('Allow users to attach products to events when submitting an event on the frontend.', 'gt3_jm_products_integration'),
						'type'        => 'checkbox'
					),

					array(
						'name'        => 'gt3_draft_products_on_listing_expiration',
						'std'         => '1',
						'placeholder' => '',
						'label'       => esc_html__('Draft Products', 'gt3_jm_products_integration'),
						'cb_label'    => esc_html__('Draft products connected to listings when the listing expires', 'gt3_jm_products_integration'),
						'desc'        => esc_html__('Force products to be set to draft when a connected listing expires.', 'gt3_jm_products_integration'),
						'type'        => 'checkbox'
					),

					array(
						'name'        => 'gt3_delete_products_with_listings',
						'std'         => '0',
						'placeholder' => '',
						'label'       => esc_html__('Delete Products', 'gt3_jm_products_integration'),
						'cb_label'    => esc_html__('Delete products connected to listings when the listing deleted', 'gt3_jm_products_integration'),
						'desc'        => esc_html__('Force products to be set to draft when a connected listing deleted.', 'gt3_jm_products_integration'),
						'type'        => 'checkbox'
					),

					/*array(
						'name'        => 'gt3_move_products',
						'label'       => esc_html__('Connect Products', 'gt3_jm_products_integration'),
						'type'        => 'button_move',
						'description' => esc_html(' Connect all the existing products using "Products Integration" plugin.','gt3_jm_products_integration'),
					),*/
				)
			);

			return $settings;
		}

		public function wp_job_manager_admin_field_button_move($option, $attributes, $value, $placeholder){
			wp_nonce_field('gt3_move_jm_products', 'gt3_move_jm_products_nonce');
			?>
			<input type="button" value="<?php esc_html_e('Connect Products', 'gt3_jm_products_integration') ?>" class="move_jm_products" /><br />
			<?php
			if (isset($option['description']) && !empty($option['description'])) {
				echo '<p class="description">'.$option['description'].'</p>';
			}
		}

		public function ajax_handler(){
			if(empty($_POST) || !wp_verify_nonce($_POST['gt3_move_jm_products_nonce'], 'gt3_move_jm_products')) {
				wp_die(wp_json_encode(array(
					'error'   => true,
					'message' => esc_html__('Error AJAX Request', 'gt3_jm_products_integration'),
				)));
			}

			$query = new WP_Query(array(
				'post_type'      => 'job_listing',
				'posts_per_page' => -1,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'     => '_products',
						'compare' => 'EXIST'
					),
					array(
						'key'     => '_gt3_products',
						'compare' => 'NOT EXISTS',
					)
				),
				'fields'         => 'ids'
			));

			if($query instanceof \WP_Query) {
				if($query->post_count) {
					foreach($query->posts as $_post) {
						update_post_meta($_post, '_gt3_products', get_post_meta($_post, '_products', true));
					}
				}
			}

			wp_die(wp_json_encode(array(
				'error' => false,
			)));
		}


		public function wp_enqueue_scripts(){
			if(is_admin()) {
				wp_enqueue_style('chosen', JOB_MANAGER_PLUGIN_URL.'/assets/css/chosen.css');
				wp_enqueue_script('chosen', JOB_MANAGER_PLUGIN_URL.'/assets/js/jquery-chosen/chosen.jquery.min.js', array( 'jquery' ), '1.1.0', true);
			}

			$submit_job_page_id = get_option('job_manager_submit_job_form_page_id', true);
			$edit_job_page_id   = get_option('job_manager_job_dashboard_page_id', true);

			if(is_admin()
			   || get_the_ID() == $submit_job_page_id
			   || get_the_ID() == $edit_job_page_id
			   || '' == $submit_job_page_id
			   || '' == $edit_job_page_id) {

				wp_register_script('gt3-products-integration', $this->js_url.'gt3-products-integration'.$this->min.'.js', array( 'jquery', 'chosen' ), self::$version);
				$max = get_option('gt3_max_selected_options', 0) == 0 ? null : intval(get_option('gt3_max_selected_options', 0));

				wp_localize_script('gt3-products-integration', 'gt3_jm_products', apply_filters('gt3_products_js_args', array(
					'max_selected_options' => $max,
					'no_results_text'      => esc_html__('Oops, nothing found!', 'gt3_jm_products_integration'),
				)));

				wp_enqueue_script('gt3-products-integration');
			}
		}


		public function draft_products_on_listing_expiration($post_id, $post){
			global $typenow;

			if($typenow === 'job_listing' && $post->post_status == 'expired') {
				// lets check for any products here
				$products = get_post_meta($post_id, '_gt3_products', true);

				if(is_array($products) && !empty($products)) {
					remove_action('save_post', array( $this, 'draft_products_on_listing_expiration' ));
					foreach($products as $product) {
						/** @var \WP_Post $product */
						wp_update_post(array(
							'ID'          => $product,
							'post_status' => 'draft'
						));
					}

					add_action('save_post', array( $this, 'draft_products_on_listing_expiration' ), 10, 2);
				}
			}
		}

		public function delete_product_with_listing($post_id){
			global $typenow;

			if($typenow === 'job_listing') {
				$products = get_post_meta($post_id, '_gt3_products', true);

				if(is_array($products) && !empty($products)) {
					foreach($products as $product) {
						/** @var \WP_Post $product */
						wp_trash_post($product);
					}
				}
			}
		}

		public function submit_event_form_fields($fields){
			global $current_user;

			$options      = array();
			$product_args = array(
				'post_type'      => 'product',
				'posts_per_page' => '-1',
				'meta_query'     => array(
					array(
						'key'     => '_visibility',
						'value'   => 'hidden',
						'compare' => '!=',
					),
				),
			);
			if('own' == get_option('gt3_products_limit', 'own') && !array_key_exists('administrator', $current_user->caps)) {
				// Don't show this field when user is not logged in
				if(!is_user_logged_in()) {
					return $fields;
				}

				$product_args['author'] = get_current_user_id();
			}

			$products = get_posts(apply_filters('gt3_event_form_products_args', $product_args));

			if(is_array($products) && !empty($products)) {
				foreach($products as $product) {
					/** @var \WP_Post $product */
					$options[$product->ID] = $product->post_title;
				}
			}

			if(class_exists('WC_Product_Vendors_Utils')) {
				$vendor_products = WC_Product_Vendors_Utils::get_vendor_product_ids();

				foreach($vendor_products as $vproduct) {
					$options[$vproduct] = get_the_title($vproduct);
				}
			}

			if(empty($options)) {
				return $fields;
			}

			$fields['event_fields']['event_products'] = array(
				'label'    => get_option('gt3_select_products_text'),
				'type'     => 'multiselect',
				'options'  => $options,
				'required' => false,
				'priority' => 20,
			);

			return $fields;

		}

		public function submit_job_form_fields($fields){
			global $current_user;

			$options      = array();
			$product_args = array(
				'post_type'      => 'product',
				'posts_per_page' => '-1',
				'meta_query'     => array(
					array(
						'key'     => '_visibility',
						'value'   => 'hidden',
						'compare' => '!=',
					),
				),
			);
			if('own' == get_option('gt3_products_limit', 'own') && !array_key_exists('administrator', $current_user->caps)) {
				// Don't show this field when user is not logged in
				if(!is_user_logged_in()) {
					return $fields;
				}

				$product_args['author'] = get_current_user_id();
			}

			$products = get_posts(apply_filters('gt3_job_form_products_args', $product_args));

			if(is_array($products) && !empty($products)) {
				foreach($products as $product) {
					/** @var \WP_Post $product */
					$options[$product->ID] = $product->post_title;
				}
			}

			if(class_exists('WC_Product_Vendors_Utils')) {
				$vendor_products = WC_Product_Vendors_Utils::get_vendor_product_ids();

				foreach($vendor_products as $vproduct) {
					$options[$vproduct] = get_the_title($vproduct);
				}
			}

			if(empty($options)) {
				return $fields;
			}

			$fields['company']['products'] = array(
				'label'    => get_option('gt3_select_products_text'),
				'type'     => 'multiselect',
				'options'  => $options,
				'required' => false,
				'priority' => 10,
			);

			return $fields;
		}

		public function update_job_data_products($job_id, $values){
			$value = isset($values['company']['products']) ? $values['company']['products'] : false;

			if($value) {
				update_post_meta($job_id, '_gt3_products', $value);
			}
		}

		public function add_event_data_fields_product($fields){
			global $current_user;

			$product_args = array(
				'post_type'      => 'product',
				'posts_per_page' => '-1',
			);
			if('own' == get_option('gt3_products_limit', 'own') && !array_key_exists('administrator', $current_user->caps)) {
				$product_args['author'] = get_current_user_id();
			}

			$products = get_posts(apply_filters('gt3_admin_job_form_products_args', $product_args));

			if(is_array($products) && !empty($products)) {
				foreach($products as $product) {
					/** @var \WP_Post $product */
					$options[$product->ID] = $product->post_title;
				}
			}

			if(class_exists('WC_Product_Vendors_Utils')) {
				$vendor_products = WC_Product_Vendors_Utils::get_vendor_product_ids();

				foreach($vendor_products as $vproduct) {
					$options[$vproduct] = get_the_title($vproduct);
				}
			}

			if(empty($options)) {
				return $fields;
			}

			$fields['_event_products'] = array(
				'label'       => get_option('gt3_select_products_text'),
				'placeholder' => '',
				'type'        => 'multiselect',
				'options'     => $options,
				'required'    => false,
			);

			return $fields;

		}

		public function add_listing_data_fields_product($fields){
			global $current_user;

			$product_args = array(
				'post_type'      => 'product',
				'posts_per_page' => '-1',
			);
			if('own' == get_option('gt3_products_limit', 'own')
			   && !array_key_exists('administrator', $current_user->caps)) {
				$product_args['author'] = get_current_user_id();
			}

			$products = get_posts(apply_filters('gt3_admin_job_form_products_args', $product_args));

			if(is_array($products) && !empty($products)) {
				foreach($products as $product) {
					/** @var \WP_Post $product */
					$options[$product->ID] = $product->post_title;
				}
			}

			if(class_exists('WC_Product_Vendors_Utils')) {
				$vendor_products = WC_Product_Vendors_Utils::get_vendor_product_ids();

				foreach($vendor_products as $vproduct) {
					$options[$vproduct] = get_the_title($vproduct);
				}
			}

			if(empty($options)) {
				return $fields;
			}

			$fields['_gt3_products'] = array(
				'label'       => get_option('gt3_select_products_text'),
				'placeholder' => '',
				'type'        => 'multiselect',
				'options'     => $options,
			);

			return $fields;
		}

		public function save_job_listing_data($post_id, $post){
			if(!isset($_POST['_gt3_products'])) {
				update_post_meta($post_id, '_gt3_products', '');
			}
		}

		public function listing_display_products($post_id = false){
			global $post;
			$back_post = $post;
			if($post_id) {
				$post = get_post($post_id);
			}

			$products = get_post_meta($post->ID, '_gt3_products', true);

			if(!is_array($products) || empty($products)) {
				return;
			}

			$args = apply_filters('woocommerce_related_products_args', array(
				'post_type'           => 'product',
				'ignore_sticky_posts' => 1,
				'no_found_rows'       => 1,
				'posts_per_page'      => -1,
				'post__in'            => $products,
			));

			$products = new WP_Query($args);

			if($products->have_posts()) { ?>
				<div class="listing products woocommerce">
					<h2><?php echo esc_html(get_option('gt3_listing_products_text')); ?></h2>
					<?php
					woocommerce_product_loop_start();

					while($products->have_posts()) {
						$products->the_post();
						wc_get_template_part('content', 'product');
					}

					woocommerce_product_loop_end(); ?>
				</div>
			<?php }
			wp_reset_postdata();
			$post = $back_post;
		}
	}

	/* @return \GT3_JM_Products_Integration_Plugin */
	function GT3_JM_Products_Integration_Plugin(){
		return GT3_JM_Products_Integration_Plugin::instance();
	}

	GT3_JM_Products_Integration_Plugin();
}
